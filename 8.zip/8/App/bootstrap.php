<?php
namespace App;

class Bootstrap
{
    public static function run()
    {
        echo 'run';
    }
}
