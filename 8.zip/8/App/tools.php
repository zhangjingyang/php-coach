<?php
function test()
{
    echo 'test';
}
